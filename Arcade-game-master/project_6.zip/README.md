# Neighbourhood-Map <br />
##1. How To Run  <br />
- Open Folder project 8.
- Open File Index.html.
- you will able to see the map and markers on it.
- you can filter search on search bar.
- you can click on marker to open information window such as rating and image.
##2. How it works<br />
- google api to load map and markers.
- foursquare api to fetch data.
- use knockout js to bind data.
- Define model and viewmodel.
- open app.js to open to see java script.
- comments will help you out to go through the code.
###--------------------END----------------------------
